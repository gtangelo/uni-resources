public class IteratorPattern {
    
    public interface Container {
        public Iterator getIterator();
    }
      
    public interface Iterator {
        public boolean hasNext();
        public Object next();
    }
      
    public class StudentRepository implements Container {
        private String[] students;
        
        public StudentRepository(String[] students) { this.students = students; }
      
        @Override
        public Iterator getIterator() {
            return new StudentIterator(students);
        }
    }
      
    public class StudentIterator implements Iterator {
        private String[] students;
        private int index = 0;
      
        public StudentIterator(String[] students) { this.students = students; }
      
        @Override
        public boolean hasNext() {
            return index < students.length;
        }
      
        @Override
        public Object next() {
            Object obj = students[index];
            index ++;
            return obj;
        }
    }
      
    public static void main (String[] args) {
        IteratorPattern ip = new IteratorPattern();
        String[] students = new String[] {"Matthew", "John", "Mark", "Luke"};
        StudentRepository studentRepo = ip.new StudentRepository(students);
        Iterator studentIterator = studentRepo.getIterator();
        // Goes through and prints all of the students
        while (studentIterator.hasNext()) {
            System.out.println(studentIterator.next().toString());
        }
    }
    
}
