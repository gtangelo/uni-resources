public class TemplatePattern {
    public abstract class Game {

        public abstract void initialize();
        public abstract void startGame();
        public abstract void stopGame();
      
        // Template part
        public final void play() {
          initialize();
          startGame();
          stopGame();
        }
      
      }
      
      public class Tetris extends Game {
        @Override
        public void initialize() { System.out.println("Tetris Game has been set up!"); }
      
        @Override
        public void startGame() { System.out.println("Tetris Game started..."); }
      
        @Override
        public void stopGame() { System.out.println("Tetris Game stopped..."); }
      }
      
      public static void main(String[] args) {
        TemplatePattern tp = new TemplatePattern();
        Game game = tp.new Tetris();
        game.play(); // Prints "Tetris Game has been set up!" then "Tetris Game started..." then "Tetris Game stopped..."
      }
}
