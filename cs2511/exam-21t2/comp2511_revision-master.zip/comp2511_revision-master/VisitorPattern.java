public class VisitorPattern {
    public interface ComputerPart {
        public void accept(Visitor visitor);
    }
      
    public interface Visitor {
        public void visit(ComputerPart obj);
    }
      
    public class Monitor implements ComputerPart {
        @Override
        public void accept(Visitor visitor) { visitor.visit(this); }
    }
      
    public class Keyboard implements ComputerPart {
        @Override
        public void accept(Visitor visitor) { visitor.visit(this); }
    }
      
    public class Computer implements ComputerPart {
        private ComputerPart[] parts;
        
        public Computer() {
            parts = new ComputerPart[] { new Keyboard(), new Monitor() };
        }
        
        @Override
        public void accept(Visitor visitor) {
            for (int i = 0; i < parts.length; i++) {
                parts[i].accept(visitor);
            }
            visitor.visit(this);
        }
    }
    
    public class ComputerVisitorDisplay implements Visitor {
        @Override
        public void visit(ComputerPart part) {
            if (part instanceof Keyboard) {
                System.out.println("Displaying the Keyboard.");
            } else if (part instanceof Monitor) {
                System.out.println("Displaying the Monitor.");
            }
        }
    }
    
    public static void main(String[] args) {
        VisitorPattern vp = new VisitorPattern();
        ComputerPart computer = vp.new Computer();
        computer.accept(vp.new ComputerVisitorDisplay()); // Prints "Displaying the Keyboard." then "Displaying the Monitor."
    }
    
}
