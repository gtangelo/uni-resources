public class AdapterPattern {
    
    public interface MediaPlayer {
        public void play(String audioType, String fileName);
    }
    
    public interface AdvancedMediaPlayer {
        public void playVLC(String fileName);
        public void playMP4(String fileName);
    }

    public class VLCPlayer implements AdvancedMediaPlayer {
        @Override
        public void playVLC(String fileName) {
            System.out.println("Playing VLC file. Name: " + fileName);
        }

        @Override
        public void playMP4(String fileName) {}
        
    }

    public class MP4Player implements AdvancedMediaPlayer {
        @Override
        public void playVLC(String fileName) {}

        @Override
        public void playMP4(String fileName) {
            System.out.println("Playing MP4 file. Name: " + fileName);
        }
        
    }

    public class MediaAdapter implements MediaPlayer {

        AdvancedMediaPlayer musicPlayer;

        public MediaAdapter(String audioType) {
            if (audioType.equalsIgnoreCase("MP4")) {
                musicPlayer = new MP4Player();
            } else if (audioType.equalsIgnoreCase("VLC")) {
                musicPlayer = new VLCPlayer();
            }
        }

        @Override
        public void play(String audioType, String fileName) {
            if (musicPlayer instanceof MP4Player) {
                musicPlayer.playMP4(fileName);
            } else if (musicPlayer instanceof VLCPlayer) {
                musicPlayer.playVLC(fileName);
            }
        }
        
    }

    public class AudioPlayer implements MediaPlayer {
        MediaAdapter adapter;

        @Override
        public void play(String audioType, String fileName) {
            // In-built ability to play MP3 audio
            if (audioType.equalsIgnoreCase("MP3")) {
                System.out.println("Playing MP3 file. Name: " + fileName);
            } else if (audioType.equalsIgnoreCase("MP4") || audioType.equalsIgnoreCase("VLC")) {
                adapter = new MediaAdapter(audioType);
                adapter.play(audioType, fileName);
            }
        }

    }

    public static void main(String[] args) {
        AdapterPattern ap = new AdapterPattern();
        AudioPlayer audio = ap.new AudioPlayer();
        audio.play("MP3", "OverTheWire.mp3");
        audio.play("MP4", "HTB.mp4");
        audio.play("VLC", "LeetCode.vlc");
    }

}
