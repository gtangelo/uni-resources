
public class SingletonPattern {
    private static SingletonPattern instance = new SingletonPattern();
    
    public static SingletonPattern getInstance() {
        return instance;
    }
    
    public void showMessage() { System.out.println("Printing Message..."); }
    
    public static void main(String[] args) {
        SingletonPattern object = SingletonPattern.getInstance();
        object.showMessage(); // Prints "Printing Message..."
    }
}