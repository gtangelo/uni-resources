
public class CompositePattern {
    public interface Node {
        public double calculate();
    }

    public abstract static class OperationNode implements Node {
        protected Node n1;
        protected Node n2;
        public OperationNode(Node n1, Node n2) {
            this.n1 = n1;
            this.n2 = n2;
        }
        @Override
        public abstract double calculate();
    }

    public static class NumberNode implements Node {
        private double value;
        public NumberNode(double value) {
            this.value = value;
        }
        @Override
        public double calculate() {
            return value;
        }
    }

    public static class AdditionOperation extends OperationNode {
        public AdditionOperation(Node n1, Node n2) {
            super(n1, n2);
        }
        @Override
        public double calculate() {
            return (n1.calculate() + n2.calculate());
        }
    }

    public static class SubtractionOperation extends OperationNode {
        public SubtractionOperation(Node n1, Node n2) {
            super(n1, n2);
        }
        @Override
        public double calculate() {
            return (n1.calculate() - n2.calculate());
        }
    }

    public static void main(String[] args) {
        Node sum = new CompositePattern.AdditionOperation(new CompositePattern.NumberNode(8), new CompositePattern.NumberNode(19));
        System.out.println(sum.calculate()); // Prints 27.1
    }
}