[//]: <> (Author: Liam Godfrey - z5256175)
[//]: <> (Notes taken in 21T2)

# COMP2511 21T2 Revision Notes

## Concepts

### Abstraction

In object-iriented programming theory, abstraction involves the facility to define objects that represent abstract "actors" that can perform work, report on and change their state, and "communicate" with other object in the system. Abstraction in OOP is where there is an 'abstract' class that is a definition and parent of its subclasses that 'extend' the abstract class.

```java
public abstract class Shape {
  private int numSides;
  public abstract void drawShape();
  public int getNumSides() {return numSides;}
  public int setNumSides(int sides) {numSides = sides;}
}
```

### Encapsulation

Encapsulation is the concept of wrapping the code and variables in functions that manipulate those variables. In Java, this is where variables that are changed / manipulated are created as private variables, and then public 'getters' and 'setters' are used to change and read these variables.

```java
public class Account {
  private int balance;
  public int getBalance() {return balance;}
  public void setBalance(int balance) {
    if (balance >= 0) {
      this.balance = balance;
    }
  }
}
```

### Inheritance

Inheritance is where a child class inherits functions and code from its parent class. Extensions of Abstract classes inherit the code of non-abstract functions, and class definitions of abstract functions. In Java, child classes can only extend one abstract parent class, whereas they can implement as many interfaces as they'd like. There are several levels of inheritance - Single (One class inherits the properties of another), Multiple (One class inherits the properties of a parent class, and that parent class inherits the properties of their parent class etc.), Hierarchial Inheritance (Multiple classes inherit one parent class)

```java

// Single
public abstract class Shape {}
public class Square extends Shape {}

// Multiple
public class ColouredSquare extends Square {}

// Heirarchial
public class Circle extends Shape {}
public class Triangle extends Shape {}

// Inheriting multiple interfaces
public interface draw { public void draw(); }
public interface colourIn { public void colourIn(Colour colour); }
public class ColouredSquare extends Square implements draw, colourIn {}

```

### Polymorphism

Polymorphism is the concept where a method can take multiple forms. This can be done where there are two functions that take different constructors in the same class, or where a child class has the same function name as a parent class. In the first example below, the Calculator.add function can take in either 2 or 3 numbers. Examples Two and Three look at inheritance and Polymorphism here. As shown, if a parent and child have the same function name, the child function is prioritized, but if the parent function is static then the parent function is called (when object is of type parent).

```java
// Example One
public static class Calculator {
  // Adds 2 numbers
  public static add(int a, int b) { return a+b; }
  // Adds 3 numbers
  public static add(int a, int b, int c) { return a+b+c; }
}

// Example Two
public class Dog {
  public void woof() { System.out.println("Woof!"); }
}
public class GoldenRetriever extends Dog {
  public void woof() { System.out.println("Woooooof!!"); }
}

public static void main(String[] args) {
  Dog d = new Dog();
  d.woof(); // Prints "Woof!"
  Dog gd = new GoldenRetriever();
  gd.woof(); // Prints "Woooooof!!"
  GoldenRetriever gr = new GoldenRetriever();
  gr.woof(); // Prints "Woooooof!!"
}

// Example Three
public class Dog {
  public static void woof() { System.out.println("Woof!"); }
}
public class GoldenRetriever extends Dog {
  public static void woof() { System.out.println("Woooooof!!"); }
}

public static void main(String[] args) {
  Dog d = new Dog();
  d.woof(); // Prints "Woof!"
  Dog gd = new GoldenRetriever();
  gd.woof(); // Prints "Woof!"
  GoldenRetriever gr = new GoldenRetriever();
  gr.woof(); // Prints "Woooooof!!"
}

```

### Objects, Classes, Interfaces

Objects in java are things that have been created in the code. For example, in a real world example, an object would be 'Liam', the class would be 'Person' with different variables like age, height, name etc. If Liam can code, he inherits an interface called 'Code' and then subsequently must implement their own version of the code function.

```java

// Class
public class Person implements Code {
  private int age;
  private double height;
  private String name;

  public Person(String name, int age, double height) {
    this.name = name;
    this.age = age;
    this.height = height;
  }

  public void code() {
    System.out.println("Initializing Mainframe...");
  }
}

// Interface
public interface Code {
  public void code();
}

// Main function to create an object
public static void main(String[] args) {
  // Create an object of type (class) Person.
  Person liam = new Person("Liam", 21, 187.96);
  // Run the code function that is implemented from the Code interface.
  liam.code();
}

```

### Method Forwarding

Method forwarding is when a function calls another function. This is used commonly in constructors of child classes that implement the parent class constructor with a small change.

```java

public class Dog {
  private String type;

  public Dog(String type) { this.type = type; }
}

public class GoldenRetriever {
  private String type = "GoldenRetriever";
  public GoldenRetriever() {
    super(type);
  }
}

```

### Method Overriding

Method overriding is typically where a child class wants their own implementation of a function that the parent class has implemented. A typical situation of method forwarding is manipulating the toString() method.

```java

public class Character {
  private int health = 100;
  private int exp = 100;

  @Override
  public String toString() {
    return "Health: " + health + "\nExperience: " + exp;
  }
}

```

### Generics

Generics is where a Java class manipulates a custom type object. This is most common in List or ArrayList objects in java.

```java

public interface Pair<K, V> {
  public K getKey();
  public V getValue();
}

public class OrderedPair<K, V> implements Pair<K, V> {
  private K key;
  private V value;

  public OrderedPair<K, V>(K key, V value) {
    this.key = key;
    this.value = value;
  }

  @Override
  public K getKey() { return key; }
  @Override
  public V getValue() { return value; }
}

public static void main(String[] args) {
  Pair<Integer, String> pair = new OrderedPair<Integer, String>(0, "Zero");
  Pair<Integer, String> pair2 = new OrderedPair<>(1, "One");
  Pair<String, Pair<String, Integer>>> pair3 = new OrderedPair<>("Pair", new OrderedPair<>("Three", 19));
  System.out.println(pair.getKey() + " " + getValue()); // Prints "0 Zero"
  System.out.println(pair3.getValue().getKey()) // Prints "Pair"
}


```

### Exceptions

Exceptions are disruptions in the normal flow of the program. Exceptions can be caught to allow the code to continue to flow, but an exception being thrown represents a problem in the code.

```java

public class Account {
  private double balance;

  public setBalance(double balance) throws Exception {
    if (balance < 0) {
      throw new Exception("Balance cannot be below 0 (zero).")
    } else {
      this.balance = balance;
    }
  }
}

```

### Domain Modeling

The domain model is a conceptual model of the domain that incorporates both behaviour and data. It's important, however, to make sure that it still follows basic OOP principles in utilizing various classes that handle specific functions for that object type.

```java

public class Incomes {
  private List<Income> incomes;
  public void applyBonus(BonusRule bonusRule) {
    for (Income income : incomes) {
      income.applyBonus(bonusRule);
    }
  }
}

public class Income {
  private double amount;
  public void applyBonus(BonusRule bonusRule) {
    double bonus = bonusRule.compute(this);
    amount += bonus;
  }
  public double getAmount() { return amount; }
}

public class ChristmasBonus extends BonusRule {
  @Override
  public double comput(Income income) {
    double bonus = income.getAmount() / 10;
    return bonus;
  }
}

```

## Principles

- **Encapsulate** what varies.
- **Favour Composition** over inheritance.
  
  > i.e favour the 'has-a' relationship over the 'is-a' relationship

- **Program to an interface**, not an implementation.

- Principle of **least knowledge** (Law of Demeter). (
  
  > Each unit should have only limited knowledge about other units, each unit should only talk to its friends (similar to encapsulation).

- **Liskov's Substitution** Principle

  > if S is a subtype of T, then objects of type T may be replaced with objects of type S.

- Classes should be **(OCP) open for extension and closed for modification**.
- **Avoid multiple/diverse** responsibilities for a class.

  > Domain Modeling

- Strive for **loosely coupled** designs between objects that interact.

  > Loose coupling means not going through multiple layers of objects to do something simple, i.e country = person.getAddress().getSuburb().getState().getCountry())

## Smells

- They are design aspects that violate fundamental design principles and impact software quality
- Code smells are usually not bugs; they are not technically incorrect and do not prevent the program from functioning.
- The indicate **weaknesses** in design that may slow down development or increase the risk of bugs or failures in the future.
- Regardless of the granularity, smells in general indicate violation of software design principles, and eventually lead to code that is rigid, fragile and require "*refactoring*"
- **Code refactoring** is the provess of **restructuring** existing computer code **without changing** its external **behaviour**.

### [Different Smells](https://refactoring.guru/refactoring/smells)

- Bloaters (Long method, Long class, Primitive obsession, Data clumps, Long parameter list)
- Object-Orientation Abusers (Alternative classes with different interfaces, refused bequest, switch statements, temporary field)
- Change preventers (Divergent change, parallel inheritance heirarchies, shotgun surgery)
- Dispensables (Comments, duplicate code, data class, dead code, lazy class, speculative generality)
- Couplers (featur ency, inappropriate intimacy, incomplete library class, message chains, middle man)

## Design Patterns

### Creational Patterns

**Creational Design** patterns deal with object creation mechanisms, trying to create objects in a manner suitable to the situation.

#### Abstract Factory

Provides an interface for creating related or dependent objects without specifying the object' concrete classes.

```java

public abstract class Shape {
  private String name;
  public Shape(String name) { this.name = name; }
}

public class Square extends Shape {
  private String name = "Square";
  public Square() { super(name); }
}

public class Circle extends Shape {
  private String name = "Circle";
  public Circle() { super(name); }
}

public interface ShapeFactory {
  public Shape createShape();
}

public class SquareFactory implements ShapeFactory {
  @Override
  public Shape create() { return new Square(); }
}

public class CircleFactory implements ShapeFactory {
  @Override
  public Shape create() { return new Circle(); }
}

public static void main(String[] args) {
  AbstractFactory factory = new SquareFactory();
  factory.create(); // Returns a Square
}

```

#### Factory Method

Allows a class to defer instantiation to subclasses.

```java

public interface Shape {
  public void draw();
}

public class Square implements Shape {
  @Override
  public void draw() { System.out.println("*Drawing of a Square*"); }
}

public class Circle implements Shape {
  @Override
  public void draw() { System.out.println("*Drawing of a Circle*"); }
}

public class ShapeFactory {
  public Shape createShape(String shapeType) {
    if (shapeType == null) { return null; }
    if (shapeType.equalsIgnoreCase("Square")) { return new Square(); }
    return null;
  }
}

public static void main(String[] args) {
  ShapeFactory factory = new ShapeFactory();
  Shape square = factory.createShape("Square");
}

```

#### Builder

Seperates the construction of a complex object from its representation so that the same construction process can create different representations.

```java

public interface Item {
  public String getName();
  public Packing packing();
  public double price();
}

public interface Packing {
  public String pack();
}

public class Wrapper implements Packing {
  @Override
  public String pack() {
    return "Wrapper";
  }
}

public class Bottle implements Packing {
  @Override
  public String pack() {
    return "Bottle";
  }
}

public abstract class Burger implements Item {
  @Override
  public Packing packing() {
    return new Wrapper();
  }

  @Override
  public abstract double price();
}

public abstract class ColdDrink implements Item {
  @Override
  public Packing packing() {
    return new Bottle();
  }

  @Override
  public abstract double price();
}

public class BeefBurger extends Burger {
  @Override
  public double price() {
    return 14.95;
  }

  @Override
  public String getName() {
    return "Beef Burger";
  }
}

public class Lemonade extends ColdDrink {
  @Override
  public double price() {
    return 2.50;
  }
  
  @Override
  public String getName() {
    return "Lemonade";
  }
}

public class Meal {
  private List<Item> items = new ArrayList<Item>();

  public void addItem(Item item) { items.add(item); }
  
  public double getCost() {
    double cost = 0;
    for (Item item : items) {
      cost += item.price();
    }
    return cost;
  }

  public void showItems() {
    for (Item item : items) {
      System.out.print("Item: " + item.getName());
      System.out.print(", Packing: " item.packing().pack());
      System.out.println(", Price: " + item.price());
    }
  }
}

public class MealBuilder {
  public Meal prepareBeefMeal() {
    Meal meal = new Meal();
    meal.addItem(new BeefBurger());
    meal.addItem(new Lemonade());
    return meal;
  }
}

public static void main(String[] args) {
  MealBuilder mealBuilder = new MealBuilder();
  Meal beefMeal = mealBuilder.prepareBeefMeal();
  beefMeal.showItems(); // Prints "Item: Beef Burger, Packing: Wrapper, Price: 14.95" then "Item: Lemonade, Packing: Bottle, Price: 2.50"
  System.out.println(beefMeal.getCost()); // Prints "16.45"
}

```

#### Singleton

Ensures that a class only has one instance and provides a global point of access to it.

```java

public class SingleObject {
  private static SingleObject instance = new SingleObject();
  private SingleObject(){}
  
  public static SingleObject getInstance() {
    return instance;
  }

  public void showMessage() { System.out.println("Printing Message..."); }
}

public static void main(String[] args) {
  SingleObject object = SingleObject.getInstance();
  object.showMessage(); // Prints "Printing Message..."
}

```

### Behavioural Patterns

**Behavioural design patterns** are design patterns that identify common communication patterns among objects and realize these patterns. By doing so, these patterns increase flexibility in carrying out this communication.

#### Iterator

Iterators are used to access the elements of an aggregate object sequentially without exposing its underlying representaiton.

```java

public class IteratorPattern {
    
  public interface Container {
    public Iterator getIterator();
  }
      
  public interface Iterator {
    public boolean hasNext();
    public Object next();
  }
      
  public class StudentRepository implements Container {
    private String[] students;
    
    public StudentRepository(String[] students) { this.students = students; }
  
    @Override
    public Iterator getIterator() {
      return new StudentIterator(students);
    }
  }
    
  public class StudentIterator implements Iterator {
    private String[] students;
    private int index = 0;
  
    public StudentIterator(String[] students) { this.students = students; }
  
    @Override
    public boolean hasNext() {
      return index < students.length;
    }
  
    @Override
    public Object next() {
      Object obj = students[index];
      index ++;
      return obj;
    }
  }
    
  public static void main (String[] args) {
    IteratorPattern ip = new IteratorPattern();
    String[] students = new String[] {"Matthew", "John", "Mark", "Luke"};
    StudentRepository studentRepo = ip.new StudentRepository(students);
    Iterator studentIterator = studentRepo.getIterator();
    // Goes through and prints all of the students
    while (studentIterator.hasNext()) {
      System.out.println(studentIterator.next().toString());
    }
  }
}

```

#### Observer

Objects register to observe an event that may be raised by another object. Also known as Public/Subscribe or Event Listener.
Problem: An entity (A) wants to be able to selectively notify (sometimes regularly) another entity/ies (B) of a certain change that's happened so that B can change it's behaviour accordingly. We know the type of entities (B) we want to notify but not how many or infact who to notify before hand.

Solution: Observer allows us to selectively add which entities to notify and can also remove those entities when no longer needed i.e feature is controlled at run time.

```java

import java.util.ArrayList;
import java.util.List;

public class ObserverPattern {
    
  public interface Observer {
    public void update();
  }
      
  public interface Subject {
    public void addObserver(Observer observer);
    public void removeObserver(Observer observer);
    public void notifyObservers();
  }
    
  public class SubjectForum implements Subject {
    List<Observer> observers = new ArrayList<Observer>();
    
    public void newPost(String content) {
      System.out.println(content);
      notifyObservers();
    }
    
    @Override
    public void addObserver(Observer observer) {
      if (!observers.contains(observer)) { observers.add(observer); }
    }
    
    @Override
    public void removeObserver(Observer observer) {
      if (observers.contains(observer)) { observers.remove(observer); }
    }
    
    @Override
    public void notifyObservers() {
      for (Observer observer : observers) {
          observer.update();
      }
    }
  }
    
  public class Student implements Observer {
    @Override
    public void update() { System.out.println("New forum post has been added!"); }
  }
    
  public static void main(String[] args) {
    ObserverPattern op = new ObserverPattern();
    SubjectForum forum = op.new SubjectForum();
    Student student = op.new Student();
    forum.addObserver((Observer) student);
    forum.newPost("Welcome to the class!"); // This prints out "Welcome to the class!" then "New forum post has been added!"  
  }
    
}

```

#### State

A clean way for an object to partially change its type at runtime.
Problem : We have multiple states that an object can be in, which dictates the way it behaves and at the moment they're implemented/controlled by a bunch of conditional statements.

Solution: Create an interface for the state that contains the behaviours that vary according to a specific state, create classes for all possible states and implement the behaviours for the state.

This may seem similar to the strategy pattern but the key difference is that particular states may at times be aware of each other where as that's seldom the case in the strategy pattern.

```java

public class StatePattern {
  public interface State {
      public void stateAction(StateObject obj);
  }
      
  public interface StateObject {
      public void setState(State state);
      public State getState();
  }
      
  public class PlayState implements State {
      @Override
      public void stateAction(StateObject obj) { 
          System.out.println("Playing...");
          obj.setState(this);
      }
  }
      
  public class PausedState implements State {
      @Override
      public void stateAction(StateObject obj) {
          System.out.println("Pausing...");
          obj.setState(this);  
      }
  }
      
  public class VideoPlayer implements StateObject {
    private State state;
      
    public VideoPlayer(State startingState) {
        state = startingState;
    }
    
    @Override
    public void setState(State state) { this.state = state; }
    @Override
    public State getState() { return state; }
  }
      
  public static void main(String[] args) {
    StatePattern sp = new StatePattern();
    VideoPlayer videoPlayer = sp.new VideoPlayer(sp.new PausedState());
    PlayState play = sp.new PlayState();
    PausedState pause = sp.new PausedState();
    play.stateAction(videoPlayer); // Prints "Playing..."
    pause.stateAction(videoPlayer); // Print "Pausing..."
    videoPlayer.getState(); // Returns type PausedState
  } 
}


```

#### Strategy

Algorithms can be selected at runtime, using composition
Problem: Too many conditional statements that dictate the way a function operates or a class whos subclasses have different algorithims for running a certain funcion.
Solution: The strategy pattern allows a class that does something specific in a lot of different ways and extract all the related algorithims
  in a seperate classes called strategies.


```java

// This is probably the worst calculator in the world, but it works for a demo

public class StrategyPattern {
  public interface OperationStrategy {
    public int calculate(int num1, int num2);
  }
  
  public class AddOperation implements OperationStrategy {
    @Override
    public int calculate(int num1, int num2) { return num1+num2; }
  }
  
  public class SubtractOperation implements OperationStrategy {
    @Override
    public int calculate(int num1, int num2) { return num1-num2; }
  }
  
  public class Calculator {
    private OperationStrategy operation;
    
    public Calculator(OperationStrategy operation) { this.operation = operation; }
    
    public int calculate(int num1, int num2) {
        return operation.calculate(num1, num2);
    }
    //Enables strategy to be set at runtime as well.
    public void setStrategy(OperationStrategy operation){this.operation = operation;}
  }
    
  public static void main(String[] args) {
    StrategyPattern sp = new StrategyPattern();
    Calculator addCalculator = sp.new Calculator(sp.new AddOperation());
    System.out.println(addCalculator.calculate(1, 4)); // Prints 5
    Calculator subtractCalculator = sp.new Calculator(sp.new SubtractOperation());
    System.out.println(subtractCalculator.calculate(4, 1)); // Prints 3
    
    // (5-2)+(1+2) = 6
    System.out.println(addCalculator.calculate(subtractCalculator.calculate(5, 2), addCalculator.calculate(1, 2))); // Prints 6
  }
}


```

#### Template

Describes the program skeleton of a program; algorithms can be selected at runtime, using inheritance.
Problem: When similar classes have a particular behaviour/algorithm they want to execute, which has multiple steps that are similar in some areas but vastly different in other areas. Current design may also have a bunch of conditional statements to execute a specific version of a step (i.e to check what instance it is to determine how a particular step should be implemented).

Solution: Break down the algorithims steps to methods and then put a series of calls to these methods in a template method e.g `.performAlgo()`. Steps can be abstract or have default implementations.

```java

public class TemplatePattern {
  public abstract class Game {

    public abstract void initialize();
    //Example of a default implementation of a "step" in the algorithim.
    public void greetPlayer(){
      System.out.println("Welcome to the game");
    }
    public abstract void startGame();
    public abstract void stopGame();
  
    // Template part
    public final void play() {
      initialize();
      greetPlayer();
      startGame();
      stopGame();
    }
  
  }
    
  public class Tetris extends Game {
    @Override
    public void initialize() { System.out.println("Tetris Game has been set up!"); }
  
    @Override
    public void startGame() { System.out.println("Tetris Game started..."); }
  
    @Override
    public void stopGame() { System.out.println("Tetris Game stopped..."); }
  }
    
  public static void main(String[] args) {
    TemplatePattern tp = new TemplatePattern();
    Game game = tp.new Tetris();
    game.play(); // Prints "Tetris Game has been set up!" then "Tetris Game started..." then "Tetris Game stopped..."
  }
}

```

#### Visitor

A way to seperate an algorithm from an object.

```java

public class VisitorPattern {
  public interface ComputerPart {
    public void accept(Visitor visitor);
  }
    
  public interface Visitor {
    public void visit(ComputerPart obj);
  }
    
  public class Monitor implements ComputerPart {
    @Override
    public void accept(Visitor visitor) { visitor.visit(this); }
  }
    
  public class Keyboard implements ComputerPart {
    @Override
    public void accept(Visitor visitor) { visitor.visit(this); }
  }
    
  public class Computer implements ComputerPart {
    private ComputerPart[] parts;
    
    public Computer() {
        parts = new ComputerPart[] { new Keyboard(), new Monitor() };
    }
    
    @Override
    public void accept(Visitor visitor) {
        for (int i = 0; i < parts.length; i++) {
            parts[i].accept(visitor);
        }
        visitor.visit(this);
    }
  }
  
  public class ComputerVisitorDisplay implements Visitor {
    @Override
    public void visit(ComputerPart part) {
        if (part instanceof Keyboard) {
            System.out.println("Displaying the Keyboard.");
        } else if (part instanceof Monitor) {
            System.out.println("Displaying the Monitor.");
        }
    }
  }
  
  public static void main(String[] args) {
    VisitorPattern vp = new VisitorPattern();
    ComputerPart computer = vp.new Computer();
    computer.accept(vp.new ComputerVisitorDisplay()); // Prints "Displaying the Keyboard." then "Displaying the Monitor."
  }
    
}

```

### Structural Patterns

**Structural design patterns** are design patterns that ease the design by identifying a simple way to realize relationships among entities.

#### Adapter

'Adapts' one interface for a class into one that a client expects.

```java

public inpublic class AdapterPattern {
    
  public interface MediaPlayer {
    public void play(String audioType, String fileName);
  }
    
  public interface AdvancedMediaPlayer {
    public void playVLC(String fileName);
    public void playMP4(String fileName);
  }

  public class VLCPlayer implements AdvancedMediaPlayer {
    @Override
    public void playVLC(String fileName) {
        System.out.println("Playing VLC file. Name: " + fileName);
    }

    @Override
    public void playMP4(String fileName) {}
  }

  public class MP4Player implements AdvancedMediaPlayer {
    @Override
    public void playVLC(String fileName) {}

    @Override
    public void playMP4(String fileName) {
        System.out.println("Playing MP4 file. Name: " + fileName);
    }
    
  }

  public class MediaAdapter implements MediaPlayer {

    AdvancedMediaPlayer musicPlayer;

    public MediaAdapter(String audioType) {
        if (audioType.equalsIgnoreCase("MP4")) {
            musicPlayer = new MP4Player();
        } else if (audioType.equalsIgnoreCase("VLC")) {
            musicPlayer = new VLCPlayer();
        }
    }

    @Override
    public void play(String audioType, String fileName) {
        if (musicPlayer instanceof MP4Player) {
            musicPlayer.playMP4(fileName);
        } else if (musicPlayer instanceof VLCPlayer) {
            musicPlayer.playVLC(fileName);
        }
    }
    
  }

  public class AudioPlayer implements MediaPlayer {
    MediaAdapter adapter;

    @Override
    public void play(String audioType, String fileName) {
        // In-built ability to play MP3 audio
        if (audioType.equalsIgnoreCase("MP3")) {
            System.out.println("Playing MP3 file. Name: " + fileName);
        } else if (audioType.equalsIgnoreCase("MP4") || audioType.equalsIgnoreCase("VLC")) {
            adapter = new MediaAdapter(audioType);
            adapter.play(audioType, fileName);
        }
    }
  }

  public static void main(String[] args) {
    AdapterPattern ap = new AdapterPattern();
    AudioPlayer audio = ap.new AudioPlayer();
    audio.play("MP3", "OverTheWire.mp3");
    audio.play("MP4", "HTB.mp4");
    audio.play("VLC", "LeetCode.vlc");
  }

}


```

#### Composite

A tree structure of objects where every object has the **same interface** (leaf and composite nodes).

```java

class CompositePattern {
  // Each object on the tree is of type Node
  interface Node {
      public double calculate();
  }

  // Operation nodes that are always branch nodes
  abstract static class OperationNode implements Node {
    protected Node n1;
    protected Node n2;
    public OperationNode(Node n1, Node n2) {
        this.n1 = n1;
        this.n2 = n2;
    }
    @Override
    public abstract double calculate();
  }

  // Number node that are always leaf nodes
  static class NumberNode implements Node {
    // Leaf nodes simply hold a number
    private double value;
    public NumberNode(double value) {
        this.value = value;
    }
    // Return the number this leaf node holds
    @Override
    public double calculate() {
        return value;
    }
  }

  // Addition Operation is a type of branch node that takes in two other nodes.
  static class AdditionOperation extends OperationNode {
    public AdditionOperation(Node n1, Node n2) {
        super(n1, n2);
    }
    @Override
    public double calculate() {
        return (n1.calculate() + n2.calculate());
    }
  }

  static class SubtractionOperation extends OperationNode {
    public SubtractionOperation(Node n1, Node n2) {
        super(n1, n2);
    }
    @Override
    public double calculate() {
        return (n1.calculate() - n2.calculate());
    }
  }

  public static void main(String[] args) {
    Node sum = new CompositePattern.AdditionOperation(new CompositePattern.NumberNode(8), new CompositePattern.NumberNode(19));
    System.out.println(sum.calculate()); // Prints 27.1
  }
}

```

#### Decorator

Add additional functionality to a class at **runtime** where subclassing would result in an exponential rise of new classes.

```java

public class DecoratorPattern {
  
  interface Shape {
    void draw();
  }

  class Circle implements Shape {
    @Override
    public void draw() { System.out.println("*Circle Drawing*"); }
  }

  class Square implements Shape {
    @Override
    public void draw() { System.out.println("*Square Drawing*"); }
  }

  abstract class ShapeDecorator implements Shape {
    protected Shape shape;

    public ShapeDecorator(Shape shape) { this.shape = shape; }
    
    @Override
    public void draw() { shape.draw(); }
  }

  class RedShapeDecorator extends ShapeDecorator {
    public RedShapeDecorator(Shape shape) { super(shape); }
    
    @Override
    public void draw() {
        shape.draw();
        setRedBorder(shape);
    }

    public void setRedBorder(Shape shape) {
        System.out.println("Border colour: Red");
    }
  }

  public static void main(String[] args) {
    DecoratorPattern dp = new DecoratorPattern();
    Shape circle = dp.new Circle();
    Shape redCircle = dp.new RedShapeDecorator(dp.new Circle());
    circle.draw(); // Prints "*Circle Drawing*"
    redCircle.draw(); // Prints "*Circle Drawing*" then "Border colour: Red"
  }
}


```

#### General steps to Override the equals function

If a the equals function is in the form of `public boolean isEquals(Object o)` our general steps for overriding the function are:

1. Check if this == o , return true
2. Check if o is null, return false
3. Check if this.getClass().equals(o.getClass(), return false if not true.
4. Cast the object appropriately so we can compare it to our `this` . Check the following to links:
    - <https://gitlab.cse.unsw.edu.au/COMP2511/21T2/21T2-practice-questions/-/blob/solutions/ProgrammingExample3/src/programmingexample3/ArrayListItemHamper.java#L135>
    - <https://gitlab.cse.unsw.edu.au/COMP2511/21T2/21T2-practice-questions/-/blob/solutions/ProgrammingExample4/src/programmingexample4/ArrayListBag.java#L108>

5. If the objects are essentially lists we can check if they're the same size.
6. We then proceed to check equality under our own special definitions/constraints of what we want equality to mean in the given context.
