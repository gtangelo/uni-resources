public class DecoratorPattern {
   
    public interface Shape {
        void draw();
    }

    public class Circle implements Shape {
        @Override
        public void draw() { System.out.println("*Circle Drawing*"); }
    }

    public class Square implements Shape {
        @Override
        public void draw() { System.out.println("*Square Drawing*"); }
    }

    public abstract class ShapeDecorator implements Shape {
        protected Shape shape;

        public ShapeDecorator(Shape shape) { this.shape = shape; }
        
        @Override
        public void draw() { shape.draw(); }
    }

    public class RedShapeDecorator extends ShapeDecorator {
        public RedShapeDecorator(Shape shape) { super(shape); }
        
        @Override
        public void draw() {
            shape.draw();
            setRedBorder(shape);
        }

        public void setRedBorder(Shape shape) {
            System.out.println("Border colour: Red");
        }
    }

    public static void main(String[] args) {
        DecoratorPattern dp = new DecoratorPattern();
        Shape circle = dp.new Circle();
        Shape redCircle = dp.new RedShapeDecorator(dp.new Circle());
        circle.draw(); // Prints "*Circle Drawing*"
        redCircle.draw(); // Prints "*Circle Drawing*" then "Border colour: Red"
    }
}
