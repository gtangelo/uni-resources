public class StrategyPattern {
    public interface OperationStrategy {
        public int calculate(int num1, int num2);
    }
    
    public class AddOperation implements OperationStrategy {
        @Override
        public int calculate(int num1, int num2) { return num1+num2; }
    }
    
    public class SubtractOperation implements OperationStrategy {
        @Override
        public int calculate(int num1, int num2) { return num1-num2; }
    }
    
    public class Calculator {
        private OperationStrategy operation;
        
        public Calculator(OperationStrategy operation) { this.operation = operation; }
        
        public int calculate(int num1, int num2) {
            return operation.calculate(num1, num2);
        }
        //Enables strategy to be set at runtime as well.
        public void setStrategy(OperationStrategy operation){this.operation = operation;}
    }
      
    public static void main(String[] args) {
        StrategyPattern sp = new StrategyPattern();
        Calculator addCalculator = sp.new Calculator(sp.new AddOperation());
        System.out.println(addCalculator.calculate(1, 4)); // Prints 5
        Calculator subtractCalculator = sp.new Calculator(sp.new SubtractOperation());
        System.out.println(subtractCalculator.calculate(4, 1)); // Prints 3
        
        // (5-2)+(1+2) = 6
        System.out.println(addCalculator.calculate(subtractCalculator.calculate(5, 2), addCalculator.calculate(1, 2))); // Prints 6
    }
    
}
