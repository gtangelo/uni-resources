import java.util.ArrayList;
import java.util.List;

public class ObserverPattern {
    
    public interface Observer {
        public void update();
    }
      
    public interface Subject {
        public void addObserver(Observer observer);
        public void removeObserver(Observer observer);
        public void notifyObservers();
    }
      
    public class SubjectForum implements Subject {
        List<Observer> observers = new ArrayList<Observer>();
        
        public void newPost(String content) {
            System.out.println(content);
            notifyObservers();
        }
        
        @Override
        public void addObserver(Observer observer) {
            if (!observers.contains(observer)) { observers.add(observer); }
        }
        
        @Override
        public void removeObserver(Observer observer) {
            if (observers.contains(observer)) { observers.remove(observer); }
        }
        
        @Override
        public void notifyObservers() {
            for (Observer observer : observers) {
                observer.update();
            }
        }
    }
      
    public class Student implements Observer {
        @Override
        public void update() { System.out.println("New forum post has been added!"); }
    }
      
    public static void main(String[] args) {
        ObserverPattern op = new ObserverPattern();
        SubjectForum forum = op.new SubjectForum();
        Student student = op.new Student();
        forum.addObserver((Observer) student);
        forum.newPost("Welcome to the class!"); // This prints out "Welcome to the class!" then "New forum post has been added!"  
    }
    
}
