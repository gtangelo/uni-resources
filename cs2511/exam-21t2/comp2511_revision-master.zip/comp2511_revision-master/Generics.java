public class Generics {
    
    public interface Pair<K, V> {
        public K getKey();
        public V getValue();
    }
      
    public class OrderedPair<K, V> implements Pair<K, V> {
        private K key;
        private V value;
      
        public OrderedPair(K key, V value) {
          this.key = key;
          this.value = value;
        }
      
        @Override
        public K getKey() { return key; }
        @Override
        public V getValue() { return value; }
    }
      
    public static void main(String[] args) {
        Generics g = new Generics();
        Pair<Integer, String> pair = g.new OrderedPair<Integer, String>(0, "Zero");
        Pair<Integer, String> pair2 = g.new OrderedPair<>(1, "One");
        Pair<String, Pair<String, Integer>> pair3 = g.new OrderedPair<>("Pair", g.new OrderedPair<>("Nineteen", 19));
        System.out.println("Key: " + pair.getKey() + ", Value: " + pair.getValue());
        System.out.println("Key: " + pair2.getKey() + ", Value: " + pair2.getValue());
        System.out.println("Key: " + pair3.getKey() + ", ValueKey: " + pair3.getValue().getKey() + ", ValueValue: " + pair3.getValue().getValue());
        System.out.println(pair3.getKey() + " " + pair3.getValue());
    }
}
